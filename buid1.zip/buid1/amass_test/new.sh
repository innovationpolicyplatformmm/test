#27/oct - integrated amass with nuclei
#29/oct - updated the skeleton
#30/oct - comparison code added
#31/oct - Had issue on big crawl like worldbank.org. 
#08/Nov - Added the time  restricktio as 5 second for each dns queries and also added the httpx check for the 20 and 302 status code
#Extras - Add multiples sources, optimisation on time complexity, add API keys, add disown
#Optimisation - run amass  in background, omit duplicates, 
#if domains_to_monitor.txt "$1" = "";then;echo "No data provided";exit;fi;
[ -s domains_to_monitor.txt ] || echo "file is empty"
echo "Subdomain enumeration initiated for "
cat domains_to_monitor.txt
amass enum  -passive -df domains_to_monitor.txt -config config.ini -o amass_results.txt -dir regular_amass_scan -max-dns-queries 10
echo "Total number of subdomains found from passive reconnaissance"
wc -l amass_results.txt
#echo "Checking for 200 and 302 status code for the list of the domains found above"
#httpx -l  amass_test/domains_nuclei.txt -sc  -mc 200,302 -o httpx_test.txt
sort < amass_results.txt > amass_sorted_results.txt
#RESULT=$(amass track -df domains_to_monitor.txt -config config.ini -last 2 -dir regular_amass_scan | grep Found | awk '{print $2}')
#FINAL_RESULT=$(while read -r d; do if grep --quiet "$d" all_domains.txt; then continue; else echo "$d"; fi; done <<< $RESULT)
#echo "$FINAL_RESULT" >> all_domains.txt
#awk '{ printf "http://"; print }' amass_sorted_results.txt > domains_nuclei.txt
#httpx -l domains_nuclei.txt -sc  -mc 200,302 -o httpx_test.txt
#echo "Total number of 200 and 302 status domains"
#wc -l httpx_test.txt
#nuclei -list domains_nuclei.txt -t takeovers/
#difference
#echo "Subdomain comparions initiated"
#comm -2 -3 <(sort amass_sorted_results.txt) <(sort sample.txt) > comparison.txt
#echo "Comparison is completed, view the file comparison.txt"
