nuclei -list amass_results.txt  -t takeovers
