import subprocess
subprocess.call(["sh","./new.sh"])
